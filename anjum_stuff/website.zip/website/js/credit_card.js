$(document).ready(function () {

    
    data = [5,6,7,8,9,10]

    $("#submit").on("click", function () {
        data = preparedata()
        console.log(data)
        submitdata(data)
    });
    
});

function submitdata(data) {
    console.log('Hello')
}

function preparedata() {
    full_name = d3.select("#name").node().value;
    gender = d3.select("#gender").node().value;
    age = d3.select("#age").node().value;
    employment = d3.select("#employment").node().value;
    property = d3.select("#property").node().value;
    marital_status = d3.select("#marital_status").node().value;
    income_source = d3.select("#income_source").node().value;
    occupation = d3.select("#occupation").node().value;
    car = d3.select("#car").node().value;
    years_working = d3.select("#years_working").node().value;
    residence = d3.select("#residence").node().value;
    education = d3.select("#education").node().value;
    income = d3.select("#income").node().value;
    cc_active_time = d3.select("#cc_active_time").node().value;
    num_children = d3.select("#num_children").node().value;
    size_family = d3.select("#size_family").node().value;
    console.log(full_name)
    console.log(gender)
    data_json = {
        'Gender': gender, 
        'Own_car': car,
        'Own_property': property, 
        'Unemployed': employment, 
        'Num_children': num_children,
        'Num_family': size_family,
        'Account_length': cc_active_time, 
        'Total_income': income,
        'Age': age, 
        'Years_employed': years_working,
        'Income_type': income_source, 
        'Education_type': education, 
        'Family_status': marital_status, 
        'Housing_type': residence,
        'Occupation_type': occupation,
    }
    return data_json;
    
}