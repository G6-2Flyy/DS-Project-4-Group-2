import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from flask import Flask

app = Flask(__name__)

@app.route("/")
def home():
    website = """Hello! Welcome to my website. Here is a link: <a href="/superheroes">Superheroes</a>"""

    return(website)